import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://thechains24.com/BUILDS/19%20builds/19%20Chains%20Builds%20Matrix.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://thechains24.com/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever.']
