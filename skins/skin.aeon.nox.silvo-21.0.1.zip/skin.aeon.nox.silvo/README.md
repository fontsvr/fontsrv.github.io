# Aeon Nox: SiLVO
[![Kodi badge](https://img.shields.io/badge/SKIN%20for-Kodi-blue.svg)](https://forum.kodi.tv/forumdisplay.php?fid=142)

**Branches:**
 - **master:** Kodi v21 Codename Omega
 - **nexus:** Kodi v20 Codename Nexus

 <hr/>

<p align="center">
  <img alt="01" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/f4983d33-ef47-4364-b794-168043505b04" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="02" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/0dbe06a3-2ce1-43c9-a06e-b1e8bef917d9" width="40%">
</p>

<p align="center">
  <img alt="03" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/da3ca11a-8a04-4bfb-965c-215acb3998e5" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="04" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/0705e7ac-bb53-41d0-a5e2-32c4ca880243" width="40%">
</p>

<p align="center">
  <img alt="05" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/831a2a67-3047-498f-b424-6db547afbfcd" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="06" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/df4dc762-38f7-4902-8b6e-08f1ceea1a05" width="40%">
</p>

<p align="center">
  <img alt="07" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/0cc45cf6-832f-4d97-8b40-d1767f56813b" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="08" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/f1ab1c40-b502-46f8-b7b3-887d1f6df494" width="40%">
</p>

<p align="center">
  <img alt="09" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/991d9427-9dcb-4c2d-bf5d-c7e7e9424e9b" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="10" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/244202e3-20fa-417c-965a-2ee3c863a828" width="40%">
</p>

<p align="center">
  <img alt="11" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/3d62cfd0-df69-4d89-8d9c-b1ca305ca5a8" width="40%">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  <img alt="12" src="https://github.com/MikeSiLVO/skin.aeon.nox.silvo/assets/3333139/18e9bb79-a785-410b-92bc-a61f4620e3ad" width="40%">
</p>